# -*- coding: utf-8 -*-
import scrapy
from baiduc.baidu.items import BaiduItem
from  scrapy.http import FormRequest
from selenium import webdriver
from scrapy.xlib.pydispatch import dispatcher
from scrapy import signals
from scrapy.http import Request
import http.client
import hashlib
import urllib
import random
import json
class BaiSpider(scrapy.Spider):
    name = 'bai'
    allowed_domains = ['www.taobao.com']
    start_urls = ['https://lp930428.taobao.com/search.htm?spm=2013.1.w5002-16582737234.1.959eebeVgbW4q&search=y']

    def parse(self, response):
        dizhi = response.xpath('//div[@class="shop-hesper-bd grid"]/div[@class="pagination"]/a[@class="J_SearchAsync next"]/@href').extract()
        dd =str(dizhi).replace('[','').replace(']','').replace("'",'')
        di='https:'+dd
        yield Request(url=di, callback=self.page,dont_filter=True)
    def page(self,response):
        dizhi = response.xpath('//dl[@*]')
        for di in dizhi:
            ur = di.xpath('dt[@class="photo"]/a[@class="J_TGoldData"]/@href').extract()
            ul =str(ur).replace('[','').replace(']','').replace("'",'')
            uu ='https:'+ ul
            yield Request(url=uu,callback=self.next,dont_filter = True)

    def next(self, response):
        item = BaiduItem()
        appid = '20170726000068236'
        secretKey = 'dDdxaBjSD0T0sCtIn1WM'
        httpClient = None
        myurl = 'https://fanyi-api.baidu.com/api/trans/vip/translate'
        url= response.xpath('//div[@id="bd"]')
        for u in url:
            img = u.xpath('div[@id="detail"]/div[@class ="tb-detail-bd tb-clear"] / div[@ class ="tb-summary tb-clear"] / div[@ class ="tb-item-info tb-clear"] / div[@ class ="tb-item-info-l"] / div[@ class ="tb-gallery"] / div[@ class ="tb-booth tb-pic tb-main-pic"] / a / span[@ class ="ks-imagezoom-wrap"] / img / @ src').extract()
            imgs = str(img).replace('[', '').replace(']', '').replace("'", '')
            im = imgs.strip()

            item['img']=im[2:]

            name = u.xpath('div[@id="detail"]/div[@class="tb-detail-bd tb-clear"]/div[@class="tb-summary tb-clear"]/div[@class="tb-item-info tb-clear"]/div[@class="tb-item-info-r"]/div[@class="tb-property tb-property-x"]/div[@class="tb-wrap tb-wrap-newshop"]/div[@class="tb-title"]/h3[@class="tb-main-title"]/text()').extract()
            names =str(name).replace('[', '').replace(']', '').replace("'", '').replace("\\", '').replace("n", '')


            price =u.xpath('div[@id="detail"]/div[@class="tb-detail-bd tb-clear"]/div[@class="tb-summary tb-clear"]/div[@class="tb-item-info tb-clear"]/div[@class="tb-item-info-r"]/div[@class="tb-property tb-property-x"]/div[@class="tb-wrap tb-wrap-newshop"]/ul[@class="tb-meta tb-promo-meta"]/li[@class="tb-detail-price tb-promo-price tb-clear"]/div[@class="tb-property-cont"]/div[@class="tb-promo-mod"]/div[@class="tb-promo-hd tb-promo-item"]/div[@class="tb-promo-item-bd"]/strong[@class="tb-promo-price"]/em[@class="tb-rmb-num"]/text()').extract()
            item['price'] = str(price).replace('[', '').replace(']', '').replace("'", '')

            yanse=u.xpath('div[@id="detail"]/div[@class="tb-detail-bd tb-clear"]/div[@class="tb-summary tb-clear"]/div[@class="tb-item-info tb-clear"]/div[@class="tb-item-info-r"]/div[@class="tb-property tb-property-x"]/div[@class="tb-wrap tb-wrap-newshop"]/div[@class="tb-key tb-key-sku"]/div[@class="tb-skin"]/dl[@class="J_Prop tb-prop tb-clear  J_Prop_Color "]/dd/ul[@class="J_TSaleProp tb-img tb-clearfix"]/li/a/span/text()').extract()
            yanses = str(yanse).replace('[', '').replace(']', '').replace("'", '')

            guize=u.xpath('div[@class="layout grid-s5m0 tb-main-layout"]/div[@class="col-main clearfix"]/div[@class="main-wrap  J_TRegion"]/div[@class="sub-wrap"]/div[@class="attributes"]/ul[@class="attributes-list"]/li/text()').extract()
            guizes= str(guize).replace('[', '').replace(']', '').replace("'", '').replace("\\xa0", '')

            q = "'" + names[2:] + "'"
            q1 ="'"+yanses+"'"
            q2="'"+guizes+"'"

            fromLang = 'zh'
            toLang = 'en'
            salt = random.randint(32768, 65536)
            salt1 = random.randint(32768, 65536)
            salt2 = random.randint(32768, 65536)
            sign = appid + q + str(salt) + secretKey
            sign1 = appid + q1 + str(salt1) + secretKey
            sign2 = appid + q2 + str(salt2) + secretKey
            m1 = hashlib.md5()
            m2 = hashlib.md5()
            m3 = hashlib.md5()

            m1.update(sign.encode("utf-8"))
            m2.update(sign1.encode("utf-8"))
            m3.update(sign2.encode("utf-8"))
            sign = m1.hexdigest()
            sign1 = m2.hexdigest()
            sign2 = m3.hexdigest()

            myurl = myurl + '?appid=' + appid + '&q=' + urllib.parse.quote(
                q) + '&from=' + fromLang + '&to=' + toLang + '&salt=' + str(salt) + '&sign=' + sign

            myurl1 = myurl + '?appid=' + appid + '&q=' + urllib.parse.quote(
                q1) + '&from=' + fromLang + '&to=' + toLang + '&salt=' + str(salt1) + '&sign=' + sign1

            myurl2 = myurl + '?appid=' + appid + '&q=' + urllib.parse.quote(
                q2) + '&from=' + fromLang + '&to=' + toLang + '&salt=' + str(salt2) + '&sign=' + sign2

            try:
                httpClient = http.client.HTTPConnection('api.fanyi.baidu.com')
                httpClient.request('GET', myurl)
                httpClient1 = http.client.HTTPConnection('api.fanyi.baidu.com')
                httpClient1.request('GET', myurl1)
                httpClient2 = http.client.HTTPConnection('api.fanyi.baidu.com')
                httpClient2.request('GET', myurl2)
                # response是HTTPResponse对象
                response = httpClient.getresponse()
                response1 = httpClient1.getresponse()
                response2 = httpClient2.getresponse()
                data = response.read().decode("utf-8")
                data1 = response1.read().decode("utf-8")
                data2 = response2.read().decode("utf-8")
                da = json.loads(data)
                da1 = json.loads(data1)
                da2 = json.loads(data2)
                item['name'] = da['trans_result'][0]['dst']
                item['yanse'] = da1['trans_result'][0]['dst']
                item['guize'] = da2['trans_result'][0]['dst']
                yield item
            finally:
                if httpClient:
                    httpClient.close()



