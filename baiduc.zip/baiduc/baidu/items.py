# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class BaiduItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    img =scrapy.Field()
    name =scrapy.Field()
    chima=scrapy.Field()
    price=scrapy.Field()
    yanse=scrapy.Field()
    guize=scrapy.Field()
    xiangqingye =scrapy.Field()
