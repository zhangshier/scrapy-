# /usr/bin/env python
# coding=utf8

import http.client
import hashlib
import urllib
import random
import json
appid = '20170726000068236'
secretKey = 'dDdxaBjSD0T0sCtIn1WM'

httpClient = None
myurl = 'https://fanyi-api.baidu.com/api/trans/vip/translate'
q = '款式:一字拖, 货号:810-X06, 品牌:other/其他, 鞋底材质:EVA发泡胶, 风格:青春潮流, 鞋面材质:塑胶, 适用季节:夏季, 颜色分类:灰色 黑色, 尺码:41 42 43 44 45, 鞋制作工艺:固特异, 图案:纯色, 鞋跟:厚底, 场合:日常, 功能:透气, 适用对象:青年（18-40周岁）'
fromLang = 'zh'
toLang = 'en'
salt = random.randint(32768, 65536)

sign = appid + q + str(salt) + secretKey
m1 = hashlib.md5()
m1.update(sign.encode("utf-8"))
sign = m1.hexdigest()
myurl = myurl + '?appid=' + appid + '&q=' + urllib.parse.quote(
    q) + '&from=' + fromLang + '&to=' + toLang + '&salt=' + str(salt) + '&sign=' + sign

try:
    httpClient = http.client.HTTPConnection('api.fanyi.baidu.com')
    httpClient.request('GET', myurl)

    # response是HTTPResponse对象
    response = httpClient.getresponse()
    data = response.read().decode("utf-8")


    da = json.loads(data)

    print(da['trans_result'][0]['dst'])
finally:
    if httpClient:
        httpClient.close()
